# CGI实验
## 编译
```
$> cd src
$> make
```

## 启动服务
```
$> cd http 
$> sudo ./myhttp start
```

## 关闭服务
```
$> cd http 
$> sudo ./myhttp stop
```

## 如果报错
```
$> chmod +x myhttp
```
## 访问
在浏览器输入 127.0.0.1:cgi/hello.cgi

![成功](cgi/succeed.png)
