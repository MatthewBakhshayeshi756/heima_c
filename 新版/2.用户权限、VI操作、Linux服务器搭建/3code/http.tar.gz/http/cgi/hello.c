#include <stdio.h>

int main(void)
{
	printf("<meta charset=utf-8 />");	//中文乱码
	printf("<img src='YBX.jpg'/>");
	printf("\nhello world!\n");
	printf("你好 杨秉学!\n");
	printf("YBX is the most handsome man in NCEPU");
	return 0;
}
